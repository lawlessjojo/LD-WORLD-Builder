# LD WorldBuilder

Standalone QBCore/oxmysql resource for Lucid Dream Roleplay.

## Features
- F10 / `/ldworldbuilder` admin-only editor.
- Searchable starter catalog of common GTA V props plus arbitrary model-name input.
- Preview and place objects with E; rotate with left/right; PageUp/PageDown attempts vertical adjustment; Backspace cancels.
- Permanent props are stored in MySQL and respawn for clients near the placement.
- Temporary placements are intended to last until restart and can be cleared with `/ldwbclear-temp`.
- Custom client-rendered lights with color, range, brightness, scene label and persistence.
- Save and reapply supported map-object hides; restore saved hides in UI.
- Database tables are created automatically through oxmysql. No manual SQL import required.

## Requirements
- FiveM server artifact supporting Lua 5.4.
- `oxmysql`.
- QBCore (`qb-core`) by default; can switch to ACE permission mode in config.

## Install
1. Extract `ld_worldbuilder` into your server resources, e.g. `resources/[ld]/ld_worldbuilder`.
2. Ensure `oxmysql` and `qb-core` start before it.
3. Add to server.cfg:
   ```
   ensure oxmysql
   ensure qb-core
   ensure ld_worldbuilder
   ```
4. Grant QBCore admin permission as appropriate, or add ACE:
   ```
   add_ace group.admin ldworldbuilder.admin allow
   ```
5. Restart the resource/server. The resource creates its tables automatically.

## Use
- Press F10 or `/ldworldbuilder`.
- Search the catalog, or type a GTA model name and press USE MODEL.
- Select persistence and scene name, then PLACE SELECTED PROP.
- In placement mode: E place, left/right arrows rotate, PageUp/PageDown adjust height, Backspace cancels.
- Use LIGHTS tab to place custom light sources.
- Use MANAGE to remove editor-placed objects.
- Aim at an existing supported map object and run `/ldwbremovemap` to save a model/coordinate hide. Use MAP CLEANUP to restore.
- `/ldwbclear-temp` clears temporary objects.

## About "all stock GTA props"
GTA V contains a very large number of stock prop models, and the game does not provide a native runtime API to enumerate every asset name. This build includes a starter catalog of common stock props and accepts any valid model name/hash. To provide a literally exhaustive search catalog, import a vetted object/model manifest from your exact GTA/FiveM asset build into `data/props.json`.

## Limitations
- Custom lights are drawn client-side using GTA's light native. Their appearance and intensity can vary by client/graphics settings; they are not baked into the world lighting.
- Map-object hiding uses `CreateModelHide`/`RemoveModelHide` by model and coordinates. It is not guaranteed to remove every type of map entity or collision element.
- Placement previews are local and the saved object is recreated client-side for nearby players; object ownership/network IDs are not used for static props.
- Temporary mode records are not stored permanently in the database. Restart cleanup is implemented by not loading temporary records; they are deleted with `/ldwbclear-temp` if any remain.
- Model names are not validated against a complete stock model manifest. Invalid model names will be rejected client-side.


## Catalog stability update
The UI now loads only the bundled local JSON catalog; it no longer downloads and parses a large remote catalog at startup. It renders at most 36 cards per search result and lazy-loads thumbnails. The bundled list includes additional ramp, stunt-track, roadblock, and barrier models. It is a curated list, not every GTA V model.
