local QBCore
if Config.Framework == 'qb' then
    QBCore = exports[Config.QBCoreResource]:GetCoreObject()
end

local function isAdmin(src)
    if src == 0 then return true end
    if IsPlayerAceAllowed(src, Config.AdminAce) then return true end
    if Config.Framework == 'qb' and QBCore then
        local ok, result = pcall(function()
            return QBCore.Functions.HasPermission(src, Config.QBPermission)
        end)
        if ok and result then return true end
    end
    return false
end

local function notify(src, msg, kind)
    TriggerClientEvent('ld_worldbuilder:client:notify', src, msg, kind or 'primary')
end

CreateThread(function()
    MySQL.query(([[
        CREATE TABLE IF NOT EXISTS `%s` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `kind` VARCHAR(16) NOT NULL DEFAULT 'prop',
            `model` VARCHAR(100) NOT NULL,
            `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL,
            `rx` DOUBLE NOT NULL DEFAULT 0, `ry` DOUBLE NOT NULL DEFAULT 0, `rz` DOUBLE NOT NULL DEFAULT 0,
            `scale` DOUBLE NOT NULL DEFAULT 1,
            `persist` VARCHAR(16) NOT NULL DEFAULT 'permanent',
            `scene` VARCHAR(100) NOT NULL DEFAULT '',
            `light_r` INT NOT NULL DEFAULT 255, `light_g` INT NOT NULL DEFAULT 255, `light_b` INT NOT NULL DEFAULT 255,
            `light_distance` DOUBLE NOT NULL DEFAULT 18, `light_brightness` DOUBLE NOT NULL DEFAULT 4,
            `created_by` VARCHAR(80) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]]):format(Config.DatabaseTable))
    MySQL.query(([[
        CREATE TABLE IF NOT EXISTS `%s_removed` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `model` VARCHAR(100) NOT NULL,
            `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL,
            `radius` DOUBLE NOT NULL DEFAULT 1.5,
            `created_by` VARCHAR(80) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]]):format(Config.DatabaseTable))
    MySQL.update(('DELETE FROM `%s` WHERE persist = ?'):format(Config.DatabaseTable), {'temporary'})
end)

local function publicRow(row)
    return {
        id = tonumber(row.id), kind = row.kind, model = row.model,
        x = tonumber(row.x), y = tonumber(row.y), z = tonumber(row.z),
        rx = tonumber(row.rx), ry = tonumber(row.ry), rz = tonumber(row.rz),
        scale = tonumber(row.scale) or 1, persist = row.persist, scene = row.scene or '',
        lightR = tonumber(row.light_r) or 255, lightG = tonumber(row.light_g) or 255,
        lightB = tonumber(row.light_b) or 255, lightDistance = tonumber(row.light_distance) or 18,
        lightBrightness = tonumber(row.light_brightness) or 4
    }
end

RegisterNetEvent('ld_worldbuilder:server:requestData', function()
    local src = source
    MySQL.query(('SELECT * FROM `%s` WHERE `persist` = ? OR `persist` = ?'):format(Config.DatabaseTable), {'permanent','temporary'}, function(rows)
        local objects = {}
        for _, row in ipairs(rows or {}) do
            if row.persist == 'permanent' then objects[#objects+1] = publicRow(row) end
        end
        MySQL.query(('SELECT * FROM `%s_removed`'):format(Config.DatabaseTable), {}, function(removed)
            local removals = {}
            for _, r in ipairs(removed or {}) do
                removals[#removals+1] = {id=tonumber(r.id), model=r.model, x=tonumber(r.x), y=tonumber(r.y), z=tonumber(r.z), radius=tonumber(r.radius) or 1.5}
            end
            TriggerClientEvent('ld_worldbuilder:client:sync', src, objects, removals)
        end)
    end)
end)

RegisterNetEvent('ld_worldbuilder:server:saveObject', function(data)
    local src = source
    if not isAdmin(src) then return notify(src, 'You do not have permission to use WorldBuilder.', 'error') end
    if type(data) ~= 'table' or type(data.model) ~= 'string' or #data.model > Config.MaxModelLength then return end
    local persist = data.persist == 'temporary' and 'temporary' or 'permanent'
    if persist == 'temporary' and not Config.AllowTemporaryObjects then return end
    if persist == 'permanent' and not Config.AllowPermanentObjects then return end
    local kind = data.kind == 'light' and 'light' or 'prop'
    local coords = data.coords or {}
    local x,y,z = tonumber(coords.x),tonumber(coords.y),tonumber(coords.z)
    if not x or not y or not z or math.abs(x)>10000 or math.abs(y)>10000 or math.abs(z)>3000 then return end
    local rot = data.rotation or {}
    local ped = GetPlayerPed(src)
    local p = GetEntityCoords(ped)
    if #(p - vector3(x,y,z)) > 100.0 then return notify(src,'Placement rejected: too far away.','error') end
    local ident = GetPlayerName(src) or ('player:%s'):format(src)
    MySQL.insert(('INSERT INTO `%s` (kind,model,x,y,z,rx,ry,rz,scale,persist,scene,light_r,light_g,light_b,light_distance,light_brightness,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'):format(Config.DatabaseTable), {
        kind,data.model,x,y,z,tonumber(rot.x) or 0,tonumber(rot.y) or 0,tonumber(rot.z) or 0,
        tonumber(data.scale) or 1,persist,tostring(data.scene or ''):sub(1,100),
        tonumber(data.lightR) or 255,tonumber(data.lightG) or 255,tonumber(data.lightB) or 255,
        tonumber(data.lightDistance) or Config.DefaultLightDistance,tonumber(data.lightBrightness) or Config.DefaultLightBrightness,ident
    }, function(id)
        data.id = id
        data.kind, data.persist = kind, persist
        data.x, data.y, data.z = x,y,z
        data.rx, data.ry, data.rz = tonumber(rot.x) or 0,tonumber(rot.y) or 0,tonumber(rot.z) or 0
        TriggerClientEvent('ld_worldbuilder:client:addObject', -1, data)
        notify(src, persist == 'permanent' and 'Object saved permanently.' or 'Object placed until server restart.', 'success')
    end)
end)

RegisterNetEvent('ld_worldbuilder:server:updateObject', function(id, data)
    local src = source
    if not isAdmin(src) or type(data) ~= 'table' then return end
    id = tonumber(id); if not id then return end
    local c, r = data.coords or {}, data.rotation or {}
    local x,y,z = tonumber(c.x), tonumber(c.y), tonumber(c.z)
    if not x or not y or not z or math.abs(x)>10000 or math.abs(y)>10000 or math.abs(z)>3000 then return end
    local ped=GetPlayerPed(src); if #(GetEntityCoords(ped)-vector3(x,y,z)) > 100.0 then return notify(src,'Move rejected: too far away.','error') end
    MySQL.update(('UPDATE `%s` SET x=?,y=?,z=?,rx=?,ry=?,rz=? WHERE id=?'):format(Config.DatabaseTable), {x,y,z,tonumber(r.x) or 0,tonumber(r.y) or 0,tonumber(r.z) or 0,id}, function()
        MySQL.query(('SELECT * FROM `%s` WHERE id = ? LIMIT 1'):format(Config.DatabaseTable), {id}, function(rows)
            if rows and rows[1] then TriggerClientEvent('ld_worldbuilder:client:updateObject',-1,publicRow(rows[1])); notify(src,'Object moved.','success') end
        end)
    end)
end)

RegisterNetEvent('ld_worldbuilder:server:editObject', function(id, scale, rz)
    local src=source; if not isAdmin(src) then return end
    id=tonumber(id); scale=tonumber(scale); rz=tonumber(rz)
    if not id or not scale or not rz then return end
    scale=math.min(math.max(scale,0.1),5.0)
    MySQL.update(('UPDATE `%s` SET scale=?,rz=? WHERE id=?'):format(Config.DatabaseTable), {scale,rz,id}, function()
        MySQL.query(('SELECT * FROM `%s` WHERE id = ? LIMIT 1'):format(Config.DatabaseTable), {id}, function(rows)
            if rows and rows[1] then TriggerClientEvent('ld_worldbuilder:client:updateObject',-1,publicRow(rows[1])); notify(src,'Object updated.','success') end
        end)
    end)
end)

RegisterNetEvent('ld_worldbuilder:server:removePlaced', function(id)
    local src = source
    if not isAdmin(src) then return end
    id = tonumber(id)
    if not id then return end
    MySQL.update(('DELETE FROM `%s` WHERE id = ?'):format(Config.DatabaseTable), {id}, function()
        TriggerClientEvent('ld_worldbuilder:client:removeObject', -1, id)
        notify(src, 'Placed object removed.', 'success')
    end)
end)

RegisterNetEvent('ld_worldbuilder:server:saveMapRemoval', function(data)
    local src = source
    if not isAdmin(src) or not Config.AllowMapObjectRemoval then return end
    if type(data) ~= 'table' or type(data.model) ~= 'string' then return end
    local c=data.coords or {}
    local x,y,z=tonumber(c.x),tonumber(c.y),tonumber(c.z)
    if not x or not y or not z then return end
    local ped=GetPlayerPed(src)
    if #(GetEntityCoords(ped)-vector3(x,y,z)) > 20.0 then return end
    local radius=math.min(math.max(tonumber(data.radius) or Config.MapRemovalRadius,0.25),10.0)
    MySQL.insert(('INSERT INTO `%s_removed` (model,x,y,z,radius,created_by) VALUES (?,?,?,?,?,?)'):format(Config.DatabaseTable),
        {data.model,x,y,z,radius,GetPlayerName(src) or tostring(src)}, function(id)
            local removal={id=id,model=data.model,x=x,y=y,z=z,radius=radius}
            TriggerClientEvent('ld_worldbuilder:client:addRemoval',-1,removal)
            notify(src,'Map-object hide saved. Restore it from the editor if needed.','success')
        end)
end)

RegisterNetEvent('ld_worldbuilder:server:restoreMapRemoval', function(id)
    local src=source
    if not isAdmin(src) then return end
    id=tonumber(id)
    if not id then return end
    MySQL.update(('DELETE FROM `%s_removed` WHERE id = ?'):format(Config.DatabaseTable),{id},function()
        TriggerClientEvent('ld_worldbuilder:client:restoreRemoval',-1,id)
        notify(src,'Saved map-object removal restored.','success')
    end)
end)

RegisterNetEvent('ld_worldbuilder:server:requestAdmin', function()
    local src=source
    TriggerClientEvent('ld_worldbuilder:client:adminResult',src,isAdmin(src))
end)

RegisterCommand('ldwbclear-temp', function(src)
    if src ~= 0 and not isAdmin(src) then return end
    MySQL.update(('DELETE FROM `%s` WHERE persist = ?'):format(Config.DatabaseTable), {'temporary'}, function()
        TriggerClientEvent('ld_worldbuilder:client:clearTemporary',-1)
        if src ~= 0 then notify(src,'Temporary placements cleared.','success') end
    end)
end, false)
