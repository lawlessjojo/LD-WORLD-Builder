Config = {}

-- Framework/permissions
Config.Framework = 'qb' -- 'qb' or 'ace'
Config.QBCoreResource = 'qb-core'
Config.AdminAce = 'ldworldbuilder.admin'
Config.QBPermission = 'admin' -- QBCore permission name
Config.Command = 'ldworldbuilder'

-- Persistence: oxmysql required.
Config.DatabaseTable = 'ld_worldbuilder_objects'
Config.LoadRadius = 350.0 -- objects farther than this are not spawned by this client
Config.StreamCheckMs = 2500
Config.MaxObjectsPerPlayer = 100
Config.MaxModelLength = 80
Config.MaxPlacementDistance = 12.0
Config.MinLightDistance = 1.0
Config.MaxLightDistance = 80.0
Config.DefaultLightDistance = 18.0
Config.DefaultLightBrightness = 4.0
Config.LightDrawDistance = 100.0
Config.AllowMapObjectRemoval = true
Config.MapRemovalRadius = 1.5
Config.AllowTemporaryObjects = true
Config.AllowPermanentObjects = true
Config.EnableUndo = true

-- This is a starter searchable stock-prop catalog, not a complete Rockstar asset manifest.
-- The UI also accepts any valid GTA model name/hash, so the catalog can be expanded without code changes.
Config.PropCatalogFile = 'data/props.json'
