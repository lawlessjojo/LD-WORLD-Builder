fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'ld_worldbuilder'
author 'Lucid Dream Roleplay'
description 'Persistent in-game world editor for props, lights, scenes, and supported map-object removals.'
version '1.0.0'

ui_page 'html/index.html'

files {
    'data/props.json',
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

shared_script 'config.lua'
client_script 'client/main.lua'
server_script '@oxmysql/lib/MySQL.lua'
server_script 'server/main.lua'
