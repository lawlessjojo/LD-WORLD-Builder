local QBCore
if Config.Framework == 'qb' then QBCore = exports[Config.QBCoreResource]:GetCoreObject() end

local uiOpen, isAdmin, placing = false, false, nil
local objects, removals, spawned = {}, {}, {}
local hiddenRemovals = {}
local undoStack = {}

local function notify(msg, kind)
    if QBCore and QBCore.Functions and QBCore.Functions.Notify then
        QBCore.Functions.Notify(msg, kind or 'primary')
    else
        BeginTextCommandThefeedPost('STRING'); AddTextComponentSubstringPlayerName(msg); EndTextCommandThefeedPostTicker(false,false)
    end
end

RegisterNetEvent('ld_worldbuilder:client:notify', notify)
local function requestModel(model)
    local hash = type(model) == 'number' and model or joaat(model)
    if not IsModelInCdimage(hash) or not IsModelValid(hash) then return nil end
    RequestModel(hash)
    local timeout = GetGameTimer() + 10000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(10) end
    if not HasModelLoaded(hash) then return nil end
    return hash
end

local function vecFrom(o) return vector3(tonumber(o.x) or 0, tonumber(o.y) or 0, tonumber(o.z) or 0) end
local function applyRemoval(r)
    local hash = type(r.model)=='number' and r.model or joaat(r.model)
    CreateModelHide(r.x,r.y,r.z,r.radius or Config.MapRemovalRadius,hash,true)
    hiddenRemovals[r.id] = r
end
local function restoreRemoval(r)
    local hash = type(r.model)=='number' and r.model or joaat(r.model)
    RemoveModelHide(r.x,r.y,r.z,r.radius or Config.MapRemovalRadius,hash,true)
    hiddenRemovals[r.id] = nil
end

local function spawnObject(o)
    if not o.id or spawned[o.id] then return end
    local pos=vecFrom(o)
    if #(GetEntityCoords(PlayerPedId())-pos) > Config.LoadRadius then return end
    if o.kind == 'light' then spawned[o.id] = {light=true,data=o}; return end
    local hash=requestModel(o.model)
    if not hash then return end
    local ent=CreateObjectNoOffset(hash,pos.x,pos.y,pos.z,false,false,false)
    if ent and ent ~= 0 then
        SetEntityRotation(ent,tonumber(o.rx) or 0,tonumber(o.ry) or 0,tonumber(o.rz) or 0,2,true)
        FreezeEntityPosition(ent,true); SetEntityInvincible(ent,true); SetEntityAsMissionEntity(ent,true,true)
        if o.scale and o.scale ~= 1 and SetObjectScale then pcall(SetObjectScale,ent,o.scale) end
        spawned[o.id]={entity=ent,data=o}
    end
    SetModelAsNoLongerNeeded(hash)
end

local function despawnObject(id)
    local s=spawned[id]
    if s and s.entity and DoesEntityExist(s.entity) then DeleteEntity(s.entity) end
    spawned[id]=nil
end

RegisterNetEvent('ld_worldbuilder:client:sync',function(data, removed)
    objects, removals = {}, {}
    for _,o in ipairs(data or {}) do objects[o.id]=o; spawnObject(o) end
    for _,r in ipairs(removed or {}) do removals[r.id]=r; applyRemoval(r) end
end)
RegisterNetEvent('ld_worldbuilder:client:addObject',function(o)
    objects[o.id]=o; spawnObject(o)
    if uiOpen then SendNUIMessage({action='lists',objects=objects,removals=removals}) end
end)
RegisterNetEvent('ld_worldbuilder:client:updateObject',function(o)
    despawnObject(tonumber(o.id)); objects[tonumber(o.id)]=o; spawnObject(o)
    if uiOpen then SendNUIMessage({action='lists',objects=objects,removals=removals}) end
end)
RegisterNetEvent('ld_worldbuilder:client:removeObject',function(id)
    despawnObject(tonumber(id)); objects[tonumber(id)]=nil
    if uiOpen then SendNUIMessage({action='lists',objects=objects,removals=removals}) end
end)
RegisterNetEvent('ld_worldbuilder:client:addRemoval',function(r)
    removals[r.id]=r; applyRemoval(r)
end)
RegisterNetEvent('ld_worldbuilder:client:restoreRemoval',function(id)
    local r=removals[tonumber(id)]
    if r then restoreRemoval(r); removals[tonumber(id)]=nil end
end)
RegisterNetEvent('ld_worldbuilder:client:clearTemporary',function()
    for id,s in pairs(spawned) do
        if s.data and s.data.persist=='temporary' then despawnObject(id) end
    end
end)
RegisterNetEvent('ld_worldbuilder:client:adminResult',function(ok)
    isAdmin=ok
    if not ok then notify('You do not have permission to use WorldBuilder.','error'); return end
    uiOpen=true
    SetNuiFocus(true,true)
    SendNUIMessage({action='open', objects=objects, removals=removals})
end)

RegisterCommand(Config.Command,function()
    TriggerServerEvent('ld_worldbuilder:server:requestAdmin')
end,false)
RegisterKeyMapping(Config.Command,'Open LD WorldBuilder','keyboard','F10')

RegisterNUICallback('close',function(_,cb)
    uiOpen=false; SetNuiFocus(false,false); SendNUIMessage({action='hide'}); cb({ok=true})
end)
RegisterNUICallback('place',function(data,cb)
    local model=tostring(data.model or '')
    if model=='' then cb({ok=false,error='Enter a model name.'}); return end
    placing={model=model,kind=data.kind=='light' and 'light' or 'prop',persist=data.persist=='temporary' and 'temporary' or 'permanent',
        scene=tostring(data.scene or ''),rotation={x=0,y=0,z=GetEntityHeading(PlayerPedId())},
        scale=tonumber(data.scale) or 1,updateId=tonumber(data.updateId),lightR=tonumber(data.lightR) or 255,lightG=tonumber(data.lightG) or 255,lightB=tonumber(data.lightB) or 255,
        lightDistance=tonumber(data.lightDistance) or Config.DefaultLightDistance,lightBrightness=tonumber(data.lightBrightness) or Config.DefaultLightBrightness}
    uiOpen=false; SetNuiFocus(false,false); SendNUIMessage({action='hide'})
    notify('Placement mode: aim at ground; E place, arrows rotate, PageUp/PageDown height, Backspace cancel.','primary')
    cb({ok=true})
end)
RegisterNUICallback('removePlaced',function(data,cb)
    TriggerServerEvent('ld_worldbuilder:server:removePlaced',tonumber(data.id)); cb({ok=true})
end)
RegisterNUICallback('moveObject',function(data,cb)
    local o=objects[tonumber(data.id)]
    if not o then cb({ok=false}); return end
    placing={model=o.model,kind=o.kind,persist=o.persist,scene=o.scene or '',rotation={x=tonumber(o.rx) or 0,y=tonumber(o.ry) or 0,z=tonumber(o.rz) or 0},scale=tonumber(o.scale) or 1,updateId=tonumber(o.id),lightR=tonumber(o.lightR) or 255,lightG=tonumber(o.lightG) or 255,lightB=tonumber(o.lightB) or 255,lightDistance=tonumber(o.lightDistance) or Config.DefaultLightDistance,lightBrightness=tonumber(o.lightBrightness) or Config.DefaultLightBrightness}
    uiOpen=false; SetNuiFocus(false,false); SendNUIMessage({action='hide'}); notify('Move mode: aim where it should go; E saves, arrows rotate, PageUp/PageDown adjust height, Backspace cancels.','primary'); cb({ok=true})
end)
RegisterNUICallback('editObject',function(data,cb) TriggerServerEvent('ld_worldbuilder:server:editObject',tonumber(data.id),tonumber(data.scale),tonumber(data.rz)); cb({ok=true}) end)
RegisterNUICallback('removeMap',function(data,cb)
    TriggerServerEvent('ld_worldbuilder:server:saveMapRemoval',data); cb({ok=true})
end)
RegisterNUICallback('restoreMap',function(data,cb)
    TriggerServerEvent('ld_worldbuilder:server:restoreMapRemoval',tonumber(data.id)); cb({ok=true})
end)
RegisterNUICallback('getLists',function(_,cb)
    local a,b={},{}
    for _,o in pairs(objects) do a[#a+1]=o end
    for _,r in pairs(removals) do b[#b+1]=r end
    cb({objects=a,removals=b})
end)

local function rotationText()
    SetTextFont(0); SetTextScale(0.32,0.32); SetTextColour(255,255,255,230); SetTextOutline()
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName('~b~LD WorldBuilder~s~  |  E place  |  ←/→ rotate  |  PgUp/PgDn height  |  Backspace cancel')
    EndTextCommandDisplayText(0.25,0.88)
end
local function rayGround()
    local ped=PlayerPedId()
    local p=GetEntityCoords(ped)
    local f=GetGameplayCamRot(2)
    local pitch, yaw=math.rad(f.x), math.rad(f.z)
    local dir=vector3(-math.sin(yaw)*math.abs(math.cos(pitch)), math.cos(yaw)*math.abs(math.cos(pitch)), math.sin(pitch))
    local dest=p+dir*Config.MaxPlacementDistance
    local ray=StartShapeTestRay(p.x,p.y+0.0,p.z+0.7,dest.x,dest.y,dest.z,1|16,ped,7)
    local _,hit,coords=GetShapeTestResult(ray)
    if hit==1 then return coords end
    local ground=GetOffsetFromEntityInWorldCoords(ped,0.0,4.0,-0.8)
    return ground
end
CreateThread(function()
    while true do
        if placing then
            Wait(0)
            local c=rayGround()
            local zOffset=0.0
            local hash=placing.kind=='prop' and requestModel(placing.model) or nil
            if placing.kind=='prop' and hash then
                local preview=CreateObjectNoOffset(hash,c.x,c.y,c.z,false,false,false)
                SetEntityAlpha(preview,140,false); SetEntityCollision(preview,false,false); FreezeEntityPosition(preview,true)
                SetEntityRotation(preview,placing.rotation.x,placing.rotation.y,placing.rotation.z,2,true)
                SetEntityDrawOutline(preview,true)
                while placing do
                    Wait(0)
                    c=rayGround()+vector3(0,0,zOffset)
                    SetEntityCoordsNoOffset(preview,c.x,c.y,c.z,false,false,false)
                    SetEntityRotation(preview,placing.rotation.x,placing.rotation.y,placing.rotation.z,2,true)
                    rotationText()
                    if IsControlJustPressed(0,174) then placing.rotation.z=placing.rotation.z-5 end
                    if IsControlJustPressed(0,175) then placing.rotation.z=placing.rotation.z+5 end
                    if IsControlJustPressed(0,10) then zOffset=zOffset+0.25 end
                    if IsControlJustPressed(0,11) then zOffset=zOffset-0.25 end
                    if IsControlJustPressed(0,38) then
                        if placing.updateId then TriggerServerEvent('ld_worldbuilder:server:updateObject',placing.updateId,{coords={x=c.x,y=c.y,z=c.z},rotation=placing.rotation}) else TriggerServerEvent('ld_worldbuilder:server:saveObject',{model=placing.model,kind=placing.kind,persist=placing.persist,scene=placing.scene,coords={x=c.x,y=c.y,z=c.z},rotation=placing.rotation,scale=placing.scale}) end
                        placing=nil
                    elseif IsControlJustPressed(0,177) then placing=nil end
                    if not placing then break end
                end
                if DoesEntityExist(preview) then DeleteEntity(preview) end
                SetModelAsNoLongerNeeded(hash)
            elseif placing.kind=='light' then
                c=c+vector3(0,0,placing.zOffset or 0)
                DrawMarker(28,c.x,c.y,c.z+0.2,0,0,0,0,0,0,0.25,0.25,0.25,placing.lightR,placing.lightG,placing.lightB,180,false,true,2,false,nil,nil,false)
                rotationText()
                if IsControlJustPressed(0,10) then placing.zOffset=(placing.zOffset or 0)+0.25 end
                if IsControlJustPressed(0,11) then placing.zOffset=(placing.zOffset or 0)-0.25 end
                if IsControlJustPressed(0,38) then
                    if placing.updateId then TriggerServerEvent('ld_worldbuilder:server:updateObject',placing.updateId,{coords={x=c.x,y=c.y,z=c.z},rotation=placing.rotation}) else TriggerServerEvent('ld_worldbuilder:server:saveObject',{model='ld_custom_light',kind='light',persist=placing.persist,scene=placing.scene,coords={x=c.x,y=c.y,z=c.z},rotation=placing.rotation,lightR=placing.lightR,lightG=placing.lightG,lightB=placing.lightB,lightDistance=placing.lightDistance,lightBrightness=placing.lightBrightness}) end
                    placing=nil
                elseif IsControlJustPressed(0,177) then placing=nil end
            else
                notify('Invalid model. Check the model name and try again.','error'); placing=nil
            end
        else Wait(250) end
    end
end)

CreateThread(function()
    while true do
        Wait(1000)
        local pos=GetEntityCoords(PlayerPedId())
        for id,o in pairs(objects) do
            local dist=#(pos-vecFrom(o))
            if dist <= Config.LoadRadius then
                if not spawned[id] then spawnObject(o) end
            elseif spawned[id] then despawnObject(id) end
        end
    end
end)

-- Existing map object removal: aim at a map object, then use /ldwbremovemap.
RegisterCommand('ldwbremovemap',function()
    if not isAdmin then TriggerServerEvent('ld_worldbuilder:server:requestAdmin'); return end
    local ped=PlayerPedId()
    local p=GetEntityCoords(ped); local f=GetGameplayCamRot(2)
    local pitch,yaw=math.rad(f.x),math.rad(f.z)
    local dir=vector3(-math.sin(yaw)*math.abs(math.cos(pitch)),math.cos(yaw)*math.abs(math.cos(pitch)),math.sin(pitch))
    local dest=p+dir*8.0
    local ray=StartShapeTestRay(p.x,p.y,p.z+0.5,dest.x,dest.y,dest.z,16,ped,7)
    local _,hit,coords,_,entity=GetShapeTestResult(ray)
    if hit~=1 or entity==0 or not DoesEntityExist(entity) then return notify('Aim at a supported map object first.','error') end
    local model=GetEntityModel(entity)
    TriggerServerEvent('ld_worldbuilder:server:saveMapRemoval',{model=tostring(model),coords={x=coords.x,y=coords.y,z=coords.z},radius=Config.MapRemovalRadius})
end,false)

AddEventHandler('onClientResourceStart',function(res)
    if res==GetCurrentResourceName() then Wait(1500); TriggerServerEvent('ld_worldbuilder:server:requestData') end
end)

-- GTA light natives must be drawn every frame; drawing them only once per second makes them appear to do nothing.
CreateThread(function()
    while true do
        local pos = GetEntityCoords(PlayerPedId())
        local found = false
        for _, s in pairs(spawned) do
            if s.light and s.data then
                local o = s.data
                if #(pos - vecFrom(o)) < Config.LightDrawDistance then
                    found = true
                    DrawLightWithRange(tonumber(o.x) or 0, tonumber(o.y) or 0, tonumber(o.z) or 0,
                        tonumber(o.lightR) or 255, tonumber(o.lightG) or 255, tonumber(o.lightB) or 255,
                        tonumber(o.lightDistance) or 18, tonumber(o.lightBrightness) or 4)
                end
            end
        end
        Wait(found and 0 or 500)
    end
end)
